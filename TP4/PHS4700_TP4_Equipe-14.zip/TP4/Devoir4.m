function [ out ] = Devoir4(PositionObs, n_o, n_t)

%main ~ish
Declarations(PositionObs, n_o, n_t);
out = 1;
end

