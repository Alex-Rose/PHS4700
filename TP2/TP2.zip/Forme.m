classdef Forme
   enumeration
      Parallelepipede, SpherePleine, SphereCreuse, CylindrePlein, CylindreCreux
   end
end