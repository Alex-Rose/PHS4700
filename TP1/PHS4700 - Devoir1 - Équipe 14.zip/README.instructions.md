# PHS4700 - Physique pour multim�dia

## Devoir 1

### Comment ex�cuter la simulation
Dans Matlab, ex�cuter le fichier *main.m*. Les r�sultats s'afficheront 
dans la console. 

Pour changer entre le patineur avec bras le long du corps et avec le bras
gauche � l'horizontale, changer la ligne 5 du fichier *main.m*. Inscrire :

* Declarations1 pour les bras le long du corps
* Declarations2 pour le bras gauche � l'horizontale

Pour activer la rotation de -10deg du patineur, mettre valeur de *incline* � *true*
dans *main.m* � la ligne 9